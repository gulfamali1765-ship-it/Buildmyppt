
import type { DesignTheme, Tone } from './types';

export const DESIGN_THEMES: DesignTheme[] = [
  {
    name: 'Minimalist',
    previewColors: ['#F3F4F6', '#6B7280', '#111827'],
    pptxTheme: {
      background: { color: 'FFFFFF' },
      title: { color: '000000', fontFace: 'Helvetica' },
      body: { color: '333333', fontFace: 'Helvetica Light' },
    },
  },
  {
    name: 'Professional',
    previewColors: ['#EFF6FF', '#3B82F6', '#1E3A8A'],
    pptxTheme: {
      background: { color: 'F0F4F8' },
      title: { color: '0A2540', fontFace: 'Arial' },
      body: { color: '2D3748', fontFace: 'Arial' },
    },
  },
  {
    name: 'Educational',
    previewColors: ['#FEFCE8', '#FBBF24', '#B45309'],
    pptxTheme: {
      background: { color: 'FFFFF0' },
      title: { color: 'C45100', fontFace: 'Georgia' },
      body: { color: '4A2E00', fontFace: 'Georgia' },
    },
  },
  {
    name: 'Creative',
    previewColors: ['#F5F3FF', '#8B5CF6', '#4C1D95'],
    pptxTheme: {
      background: { color: 'FDFBFF' },
      title: { color: '6D28D9', fontFace: 'Futura' },
      body: { color: '262626', fontFace: 'Futura' },
    },
  },
  {
    name: 'Dark Mode',
    previewColors: ['#1F2937', '#4B5563', '#F9FAFB'],
    pptxTheme: {
      background: { color: '111827' },
      title: { color: 'F9FAFB', fontFace: 'Verdana' },
      body: { color: 'D1D5DB', fontFace: 'Verdana' },
    },
  },
  {
    name: 'Modern Gradient',
    previewColors: ['#ECFEFF', '#22D3EE', '#0E7490'],
    pptxTheme: {
      background: { color: 'E0F2FE' },
      title: { color: '083344', fontFace: 'Gill Sans' },
      body: { color: '075985', fontFace: 'Gill Sans' },
    },
  },
  {
    name: 'Vibrant',
    previewColors: ['#FFFBEB', '#FB923C', '#D97706'],
    pptxTheme: {
      background: { color: 'FEF3C7' },
      title: { color: 'C2410C', fontFace: 'Impact' },
      body: { color: '78350F', fontFace: 'Tahoma' },
    },
  },
  {
    name: 'Oceanic',
    previewColors: ['#F0FDFA', '#2DD4BF', '#0D9488'],
    pptxTheme: {
      background: { color: 'CFFAFE' },
      title: { color: '0E7490', fontFace: 'Trebuchet MS' },
      body: { color: '155E75', fontFace: 'Trebuchet MS' },
    },
  },
    {
    name: 'Autumn',
    previewColors: ['#FEFBF6', '#D97706', '#92400E'],
    pptxTheme: {
      background: { color: 'FEF3E0' },
      title: { color: '9A3412', fontFace: 'Garamond' },
      body: { color: '78350F', fontFace: 'Garamond' },
    },
  }
];

export const TONES: Tone[] = [
  { name: 'Academic', description: 'Formal, well-researched, and cited.' },
  { name: 'Business', description: 'Professional, results-oriented, and clear.' },
  { name: 'Storytelling', description: 'Engaging, narrative-driven, and personal.' },
  { name: 'Technical', description: 'Detailed, precise, and data-focused.' },
];
