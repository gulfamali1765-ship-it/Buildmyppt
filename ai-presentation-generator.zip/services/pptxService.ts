
import PptxGenJS from 'pptxgenjs';
import type { Slide, PptxTheme } from '../types';

export const createPptx = (slides: Slide[], theme: PptxTheme, includeImages: boolean, topic: string) => {
  const pres = new PptxGenJS();

  pres.layout = 'LAYOUT_WIDE';
  
  // Define a master slide for consistent branding if needed
  pres.defineSlideMaster({
    title: 'MASTER_SLIDE',
    background: { color: theme.background.color },
  });

  slides.forEach((slideData, index) => {
    const slide = pres.addSlide({ masterName: 'MASTER_SLIDE' });

    // Title
    slide.addText(slideData.title, {
      x: 0.5,
      y: index === 0 ? 1.5 : 0.5,
      w: '90%',
      h: 1,
      fontSize: index === 0 ? 44 : 32,
      bold: true,
      color: theme.title.color,
      fontFace: theme.title.fontFace,
      align: index === 0 ? 'center' : 'left',
    });

    // Content
    if (slideData.content.length > 0) {
      slide.addText(slideData.content.join('\n'), {
        x: 0.5,
        y: index === 0 ? 2.75 : 1.5,
        w: '90%',
        h: '70%',
        fontSize: 18,
        color: theme.body.color,
        fontFace: theme.body.fontFace,
        bullet: { type: 'bullet' },
        lineSpacing: 36
      });
    }

    // Optional Image Placeholder
    if (includeImages && slideData.imageQuery) {
        const imageUrl = `https://picsum.photos/seed/${encodeURIComponent(slideData.imageQuery)}/800/200`;
        slide.addImage({
            path: imageUrl,
            x: '70%', 
            y: '75%', 
            w: '25%', 
            h: '15%'
        });
        slide.addText(`Image Suggestion: ${slideData.imageQuery}`, {
           x: '70%', 
           y: '92%', 
           w: '25%', 
           h: '5%',
           fontSize: 8,
           color: theme.body.color,
           italic: true
        });
    }
  });
  
  const fileName = `${topic.replace(/[^a-zA-Z0-9]/g, '_') || 'presentation'}.pptx`;
  pres.writeFile({ fileName });
};
