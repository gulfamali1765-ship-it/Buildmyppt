
import { GoogleGenAI, Type } from "@google/genai";
import type { InputType, Slide } from '../types';

if (!process.env.API_KEY) {
    console.warn("API_KEY environment variable not set. Using a placeholder.");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY! });

const slideSchema = {
  type: Type.OBJECT,
  properties: {
    title: {
      type: Type.STRING,
      description: 'The title of the slide. Should be concise and engaging.',
    },
    content: {
      type: Type.ARRAY,
      items: { type: Type.STRING },
      description: 'An array of strings, where each string is a bullet point for the slide content. Keep points brief.',
    },
    imageQuery: {
      type: Type.STRING,
      description: 'A simple, effective search query for a relevant background image or icon for this slide. E.g., "team collaboration" or "data analysis chart".',
    },
  },
  required: ['title', 'content'],
};

export const generateSlidesContent = async (
  inputType: InputType,
  source: string,
  slideCount: number,
  designTheme: string,
  includeImages: boolean,
  tone: string
): Promise<Slide[]> => {
  const contentPreamble = {
    'topic': `A presentation on the topic: "${source}"`,
    'text': `A presentation based on the following text/notes: "${source}"`,
    'file': `A presentation summarizing the key points from a document titled: "${source}"`
  }[inputType];

  const prompt = `
    You are an expert presentation creator. Your task is to generate the content for a slide deck based on the user's request.

    **Presentation Details:**
    - **Source:** ${contentPreamble}
    - **Approximate Number of Slides:** ${slideCount}
    - **Design Theme:** ${designTheme}
    - **Tone:** ${tone}
    - **Include Image Suggestions:** ${includeImages}
    
    **Instructions:**
    1.  Create a logical flow for the presentation, including a title slide, introduction, main body slides, and a conclusion.
    2.  Write a clear, concise title for each slide.
    3.  For each slide's content, provide short, impactful bullet points.
    4.  If "Include Image Suggestions" is true, provide a relevant 'imageQuery' for each slide. Otherwise, you can omit it.
    5.  Adhere to the requested tone and theme to influence the style of the content.
    6.  Ensure the total number of slides is approximately ${slideCount}.
    
    Generate the content and structure it according to the provided JSON schema.
  `;

  try {
    const response = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: prompt,
        config: {
            responseMimeType: "application/json",
            responseSchema: {
                type: Type.ARRAY,
                items: slideSchema,
            },
        },
    });

    const jsonText = response.text.trim();
    const slides: Slide[] = JSON.parse(jsonText);
    return slides;
  } catch (error) {
    console.error("Error generating slides with Gemini:", error);
    throw new Error("Failed to generate presentation content. Please check your API key and try again.");
  }
};
