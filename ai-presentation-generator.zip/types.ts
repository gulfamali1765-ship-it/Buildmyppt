
export type InputType = 'topic' | 'text' | 'file';

export interface Slide {
  title: string;
  content: string[];
  imageQuery?: string;
}

export interface DesignTheme {
  name: string;
  previewColors: string[];
  pptxTheme: PptxTheme;
}

export interface PptxTheme {
  background: { color: string };
  title: { color: string; fontFace: string };
  body: { color: string; fontFace: string };
}

export interface Tone {
  name: string;
  description: string;
}

export interface StoredPresentation {
    id: string;
    topic: string;
    slides: Slide[];
    themeName: string;
    toneName: string;
    includeImages: boolean;
    createdAt: string;
}
