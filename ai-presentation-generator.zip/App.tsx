
import React, { useState, useMemo, useCallback, useEffect } from 'react';
import { generateSlidesContent } from './services/geminiService';
import { createPptx } from './services/pptxService';
import { DESIGN_THEMES, TONES } from './constants';
import type { InputType, DesignTheme, Tone, Slide, StoredPresentation } from './types';
import { PresentationIcon } from './components/icons/PresentationIcon';
import { DownloadIcon } from './components/icons/DownloadIcon';
import { EditIcon } from './components/icons/EditIcon';
import { TrashIcon } from './components/icons/TrashIcon';

const InputTypeSelector: React.FC<{ selected: InputType; onSelect: (type: InputType) => void }> = ({ selected, onSelect }) => {
  const types: { id: InputType; label: string }[] = [
    { id: 'topic', label: 'From Topic' },
    { id: 'text', label: 'From Text' },
    { id: 'file', label: 'From File' },
  ];

  return (
    <div className="flex bg-gray-200 rounded-lg p-1">
      {types.map((type) => (
        <button
          key={type.id}
          onClick={() => onSelect(type.id)}
          className={`w-full py-2 px-4 rounded-md text-sm font-semibold transition-colors duration-200 focus:outline-none ${
            selected === type.id
              ? 'bg-brand-blue text-white shadow'
              : 'text-brand-text-secondary hover:bg-gray-300'
          }`}
        >
          {type.label}
        </button>
      ))}
    </div>
  );
};

const ThemeSelector: React.FC<{ selected: DesignTheme; onSelect: (theme: DesignTheme) => void }> = ({ selected, onSelect }) => (
    <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
        {DESIGN_THEMES.map((theme) => {
            const themeStyle = {
                bg: `#${theme.pptxTheme.background.color}`,
                titleColor: `#${theme.pptxTheme.title.color}`,
                titleFont: theme.pptxTheme.title.fontFace.split(',')[0], // Use first font
                bodyColor: `#${theme.pptxTheme.body.color}`,
                bodyFont: theme.pptxTheme.body.fontFace.split(',')[0],
            };
            return (
                <button
                    key={theme.name}
                    onClick={() => onSelect(theme)}
                    className={`p-2 rounded-lg border-2 transition-all duration-200 ${selected.name === theme.name ? 'border-brand-blue ring-2 ring-brand-blue' : 'border-gray-300 hover:border-brand-blue'}`}
                >
                    <div className="w-full h-20 rounded overflow-hidden flex flex-col justify-center items-center text-left" style={{ backgroundColor: themeStyle.bg }}>
                        <div className="px-2 w-full transform scale-90">
                           <p style={{ color: themeStyle.titleColor, fontFamily: `'${themeStyle.titleFont}', sans-serif`, fontSize: '0.75rem', fontWeight: 'bold', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>Title Preview</p>
                           <p style={{ color: themeStyle.bodyColor, fontFamily: `'${themeStyle.bodyFont}', sans-serif`, fontSize: '0.6rem', marginTop: '4px' }}>• Body text preview...</p>
                        </div>
                    </div>
                    <p className="mt-2 text-sm font-semibold text-center text-brand-text-primary">{theme.name}</p>
                </button>
            )
        })}
    </div>
);

const PresentationEditor: React.FC<{
    presentation: StoredPresentation | null;
    onSave: (updatedPresentation: StoredPresentation) => void;
    onClose: () => void;
}> = ({ presentation, onSave, onClose }) => {
    const [editedSlides, setEditedSlides] = useState<Slide[]>([]);

    useEffect(() => {
        if (presentation) {
            setEditedSlides(JSON.parse(JSON.stringify(presentation.slides))); // Deep copy
        }
    }, [presentation]);

    if (!presentation) return null;

    const handleSlideChange = (index: number, field: 'title' | 'content', value: string) => {
        const newSlides = [...editedSlides];
        if (field === 'content') {
            newSlides[index][field] = value.split('\n');
        } else {
            newSlides[index][field] = value;
        }
        setEditedSlides(newSlides);
    };
    
    const handleSave = () => {
        onSave({ ...presentation, slides: editedSlides });
    }

    return (
        <div className="fixed inset-0 bg-black bg-opacity-60 flex justify-center items-start z-50 p-4 overflow-y-auto">
            <div className="bg-white rounded-xl shadow-2xl mt-8 mb-8 w-full max-w-3xl">
                <div className="p-6 border-b">
                    <h2 className="text-2xl font-bold text-brand-text-primary">Edit Presentation</h2>
                    <p className="text-brand-text-secondary">Topic: {presentation.topic}</p>
                </div>
                <div className="p-6 space-y-4 max-h-[60vh] overflow-y-auto">
                    {editedSlides.map((slide, index) => (
                        <div key={index} className="p-4 bg-gray-50 rounded-lg border">
                            <h3 className="font-semibold text-brand-text-secondary mb-2">Slide {index + 1}</h3>
                            <input
                                type="text"
                                value={slide.title}
                                onChange={(e) => handleSlideChange(index, 'title', e.target.value)}
                                className="w-full p-2 border border-gray-300 rounded-md font-bold text-lg"
                            />
                            <textarea
                                value={slide.content.join('\n')}
                                onChange={(e) => handleSlideChange(index, 'content', e.target.value)}
                                className="w-full p-2 border border-gray-300 rounded-md mt-2 h-24 text-sm resize-y"
                                placeholder="Enter bullet points, one per line."
                            />
                        </div>
                    ))}
                </div>
                 <div className="p-6 bg-gray-50 rounded-b-xl flex justify-end items-center space-x-3">
                    <button onClick={onClose} className="py-2 px-4 bg-gray-200 text-brand-text-secondary font-semibold rounded-lg hover:bg-gray-300">Cancel</button>
                    <button onClick={handleSave} className="py-2 px-4 bg-brand-blue text-white font-semibold rounded-lg hover:bg-brand-blue-dark">Save & Close</button>
                </div>
            </div>
        </div>
    );
};


const App: React.FC = () => {
    const [inputType, setInputType] = useState<InputType>('topic');
    const [topic, setTopic] = useState<string>('');
    const [textContent, setTextContent] = useState<string>('');
    const [fileName, setFileName] = useState<string>('');
    const [slideCount, setSlideCount] = useState<number>(10);
    const [selectedTheme, setSelectedTheme] = useState<DesignTheme>(DESIGN_THEMES[0]);
    const [includeImages, setIncludeImages] = useState<boolean>(true);
    const [selectedTone, setSelectedTone] = useState<Tone>(TONES[1]);
    const [isLoading, setIsLoading] = useState<boolean>(false);
    const [error, setError] = useState<string | null>(null);
    const [generated, setGenerated] = useState<boolean>(false);
    
    // History State
    const [presentations, setPresentations] = useState<StoredPresentation[]>([]);
    const [editingPresentation, setEditingPresentation] = useState<StoredPresentation | null>(null);

    // Load from localStorage on mount
    useEffect(() => {
        try {
            const saved = localStorage.getItem('presentations');
            if (saved) {
                setPresentations(JSON.parse(saved));
            }
        } catch (e) {
            console.error("Failed to load presentations from localStorage", e);
        }
    }, []);

    // Save to localStorage on change
    useEffect(() => {
        try {
            localStorage.setItem('presentations', JSON.stringify(presentations));
        } catch (e) {
            console.error("Failed to save presentations to localStorage", e);
        }
    }, [presentations]);


    const sourceContent = useMemo(() => {
        switch (inputType) {
            case 'topic': return topic;
            case 'text': return textContent;
            case 'file': return fileName;
            default: return '';
        }
    }, [inputType, topic, textContent, fileName]);

    const isGenerateDisabled = useMemo(() => !sourceContent.trim() || isLoading, [sourceContent, isLoading]);
    
    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file) {
            setFileName(file.name);
            alert("Note: File content is not processed in this demo. The presentation will be based on the file name as the topic.");
        }
    };

    const handleGenerate = useCallback(async () => {
        if (isGenerateDisabled) return;
        
        setError(null);
        setIsLoading(true);
        setGenerated(false);

        try {
            const slides = await generateSlidesContent(
                inputType,
                sourceContent,
                slideCount,
                selectedTheme.name,
                includeImages,
                selectedTone.name
            );

            if (slides && slides.length > 0) {
                 createPptx(slides, selectedTheme.pptxTheme, includeImages, topic || "presentation");
                 setGenerated(true);
                 
                 // Save to history
                 const newPresentation: StoredPresentation = {
                     id: `pres_${Date.now()}`,
                     topic: topic || textContent.substring(0, 40) || fileName,
                     slides,
                     themeName: selectedTheme.name,
                     toneName: selectedTone.name,
                     includeImages,
                     createdAt: new Date().toISOString()
                 };
                 setPresentations(prev => [newPresentation, ...prev]);

            } else {
                throw new Error("The AI returned no slides. Please try a different input.");
            }

        } catch (err: any) {
            setError(err.message || 'An unexpected error occurred.');
        } finally {
            setIsLoading(false);
        }
    }, [isGenerateDisabled, inputType, sourceContent, slideCount, selectedTheme, includeImages, selectedTone, topic, textContent, fileName]);
    
    const handleDeletePresentation = (id: string) => {
        if (window.confirm("Are you sure you want to delete this presentation?")) {
            setPresentations(presentations.filter(p => p.id !== id));
        }
    };
    
    const handleDownloadPresentation = (p: StoredPresentation) => {
        const theme = DESIGN_THEMES.find(t => t.name === p.themeName) || DESIGN_THEMES[0];
        createPptx(p.slides, theme.pptxTheme, p.includeImages, p.topic);
    }
    
    const handleSaveEdit = (updated: StoredPresentation) => {
        setPresentations(presentations.map(p => p.id === updated.id ? updated : p));
        setEditingPresentation(null);
    }
    
    const Card: React.FC<{title: string, children: React.ReactNode, className?: string}> = ({ title, children, className }) => (
      <div className={`bg-brand-surface rounded-xl shadow-md p-6 ${className}`}>
        <h2 className="text-xl font-bold text-brand-text-primary mb-4">{title}</h2>
        {children}
      </div>
    );

    return (
        <div className="min-h-screen font-sans text-brand-text-primary">
            {editingPresentation && <PresentationEditor presentation={editingPresentation} onSave={handleSaveEdit} onClose={() => setEditingPresentation(null)} />}
            <header className="bg-brand-surface shadow-sm py-4">
                <div className="container mx-auto px-4 flex items-center space-x-3">
                    <PresentationIcon className="w-8 h-8 text-brand-blue" />
                    <h1 className="text-2xl font-bold text-brand-text-primary">AI Presentation Generator</h1>
                </div>
            </header>

            <main className="container mx-auto p-4 md:p-8">
                <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-3 gap-8">
                    <div className="lg:col-span-2 space-y-6">
                       <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                            <div className="space-y-6">
                                <Card title="1. Choose Your Input">
                                    <InputTypeSelector selected={inputType} onSelect={setInputType} />
                                    <div className="mt-4">
                                        {inputType === 'topic' && <input type="text" value={topic} onChange={e => setTopic(e.target.value)} placeholder="e.g., The Future of Renewable Energy" className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-brand-blue" />}
                                        {inputType === 'text' && <textarea value={textContent} onChange={e => setTextContent(e.target.value)} placeholder="Paste your notes, bullet points, or raw text here..." className="w-full p-3 border border-gray-300 rounded-lg h-36 resize-y focus:ring-2 focus:ring-brand-blue" />}
                                        {inputType === 'file' && <div className="w-full p-3 border border-dashed border-gray-400 rounded-lg text-center">
                                            <label htmlFor="file-upload" className="cursor-pointer text-brand-blue font-semibold">
                                                {fileName ? `Selected: ${fileName}` : 'Choose a PDF or DOCX file'}
                                            </label>
                                            <input id="file-upload" type="file" accept=".pdf,.docx" onChange={handleFileChange} className="hidden" />
                                        </div>}
                                    </div>
                                </Card>
                                
                                <Card title="2. Customize Your Presentation">
                                    <div className="space-y-4">
                                        <div>
                                            <label className="font-semibold">Number of Slides: {slideCount}</label>
                                            <input type="range" min="3" max="20" value={slideCount} onChange={e => setSlideCount(Number(e.target.value))} className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer" />
                                        </div>
                                        <div>
                                            <label className="font-semibold">Tone & Style</label>
                                            <select value={selectedTone.name} onChange={e => setSelectedTone(TONES.find(t => t.name === e.target.value)!)} className="w-full p-2 border border-gray-300 rounded-lg mt-1">
                                                {TONES.map(tone => <option key={tone.name} value={tone.name}>{tone.name}</option>)}
                                            </select>
                                        </div>
                                        <div className="flex items-center justify-between">
                                            <span className="font-semibold">Include Images</span>
                                            <button onClick={() => setIncludeImages(!includeImages)} className={`w-12 h-6 rounded-full flex items-center transition-colors duration-300 focus:outline-none ${includeImages ? 'bg-brand-blue' : 'bg-gray-300'}`}>
                                                <span className={`inline-block w-5 h-5 bg-white rounded-full shadow-md transform transition-transform duration-300 ${includeImages ? 'translate-x-6' : 'translate-x-1'}`}></span>
                                            </button>
                                        </div>
                                    </div>
                                </Card>
                            </div>
                            <div className="space-y-6">
                                <Card title="3. Select a Design Theme">
                                    <ThemeSelector selected={selectedTheme} onSelect={setSelectedTheme} />
                                </Card>
                            </div>
                       </div>
                        <div className="mt-6">
                            <button
                                onClick={handleGenerate}
                                disabled={isGenerateDisabled}
                                className="w-full flex items-center justify-center py-4 px-6 bg-brand-blue text-white font-bold rounded-lg shadow-lg hover:bg-brand-blue-dark transition-all duration-200 disabled:bg-gray-400 disabled:cursor-not-allowed"
                            >
                                {isLoading ? (
                                    <>
                                        <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                                            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                                        </svg>
                                        Generating...
                                    </>
                                ) : (
                                    <>
                                        <DownloadIcon className="w-6 h-6 mr-2" />
                                        Generate & Download .pptx
                                    </>
                                )}
                            </button>
                            {error && <p className="text-red-500 text-sm mt-4 text-center">{error}</p>}
                            {generated && !isLoading && <p className="text-green-600 text-sm mt-4 text-center font-semibold">Your presentation has been downloaded and saved to history!</p>}
                        </div>
                    </div>

                    <div className="space-y-6 lg:col-span-1">
                        <Card title="My Presentations" className="max-h-[80vh] flex flex-col">
                           <div className="flex-grow overflow-y-auto pr-2 -mr-2">
                             {presentations.length > 0 ? (
                                <ul className="space-y-3">
                                    {presentations.map(p => (
                                        <li key={p.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
                                            <div className="flex-1 overflow-hidden">
                                                <p className="font-semibold truncate" title={p.topic}>{p.topic}</p>
                                                <p className="text-xs text-gray-500">Created: {new Date(p.createdAt).toLocaleDateString()}</p>
                                            </div>
                                            <div className="flex items-center space-x-1 shrink-0 ml-2">
                                                <button onClick={() => setEditingPresentation(p)} title="Edit" className="p-2 text-gray-500 hover:text-brand-blue rounded-full hover:bg-blue-100"><EditIcon className="w-4 h-4" /></button>
                                                <button onClick={() => handleDownloadPresentation(p)} title="Download" className="p-2 text-gray-500 hover:text-brand-blue rounded-full hover:bg-blue-100"><DownloadIcon className="w-4 h-4" /></button>
                                                <button onClick={() => handleDeletePresentation(p.id)} title="Delete" className="p-2 text-gray-500 hover:text-red-500 rounded-full hover:bg-red-100"><TrashIcon className="w-4 h-4" /></button>
                                            </div>
                                        </li>
                                    ))}
                                </ul>
                            ) : (
                                <p className="text-brand-text-secondary text-center py-8">No presentations generated yet.</p>
                            )}
                           </div>
                        </Card>
                    </div>
                </div>
            </main>
        </div>
    );
}

export default App;
